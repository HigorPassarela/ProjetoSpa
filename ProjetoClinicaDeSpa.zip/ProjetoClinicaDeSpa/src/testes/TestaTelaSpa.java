package testes;

import telas.TelaSpa;

public class TestaTelaSpa {
    public static void main(String[] args) {
        TelaSpa telaSpa = new TelaSpa("Clinica Spa Zen");
        telaSpa.setVisible(true);
    }
}
