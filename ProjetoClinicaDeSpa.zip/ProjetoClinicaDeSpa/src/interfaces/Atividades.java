package interfaces;

public interface Atividades {
    String TipoAtividade();
}
