package classes;

public class CalcularPeso {
    protected double altura;
    protected double pesoIdeal;
    protected double peso;


    //Construtor
    public CalcularPeso(double altura, double peso) {
        this.altura = altura;
        this.peso = peso;
    }

    //Metodos

}
